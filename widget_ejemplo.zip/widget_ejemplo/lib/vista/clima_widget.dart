import 'package:flutter/material.dart';

class ClimaWidget extends StatelessWidget {
  final String ciudad;
  final double temperatura;
  final String descripcion;

  ClimaWidget({
    required this.ciudad,
    required this.temperatura,
    required this.descripcion,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.blue[50],
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      margin: EdgeInsets.all(8),
      //elevation: 5, // Elevación para sombra
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Ícono del clima
            Icon(
              Icons.wb_sunny, // Ícono representativo
              size: 50,
              color: Colors.orangeAccent,
            ),
            SizedBox(width: 16),
            // Información del clima
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Nombre de la ciudad
                  Text(
                    'Ciudad: $ciudad',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[800],
                    ),
                  ),
                  SizedBox(height: 10),
                  // Temperatura
                  Text(
                    'Temperatura: ${temperatura.toStringAsFixed(1)}°C',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.blue[700],
                    ),
                  ),
                  SizedBox(height: 10),
                  // Descripción del clima
                  Text(
                    'Descripción: $descripcion',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.blueGrey[600],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
