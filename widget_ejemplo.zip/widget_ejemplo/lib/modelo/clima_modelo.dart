class ClimaModelo {
  final String ciudad;
  final double temperatura;
  final String descripcion;

  ClimaModelo({
    required this.ciudad,
    required this.temperatura,
    required this.descripcion,
  });

  // Convertir JSON a objeto con validación
  factory ClimaModelo.fromJson(Map<String, dynamic> json) {
    return ClimaModelo(
      ciudad: json['name'] ?? 'Ciudad desconocida',
      temperatura: (json['main']?['temp'] ?? 0).toDouble(),
      descripcion: (json['weather']?[0]['description'] ?? 'Sin descripción'),
    );
  }
}
