import 'dart:convert';
import 'package:http/http.dart' as http;
import '../modelo/clima_modelo.dart';

class ClimaControlador {
  final String apikey = '6ba0cd4fd13d42f36e513e213423c82f';
  final String apiurl = 'https://api.openweathermap.org/data/2.5/weather';

  Future<ClimaModelo?> obtenerClima(String ciudad) async {
    final url = Uri.parse('$apiurl?q=$ciudad&units=metric&appid=$apikey&lang=es');
    try {
      final respuesta = await http.get(url);

      if (respuesta.statusCode == 200) {
        final json = jsonDecode(respuesta.body);

        // Validar la estructura del JSON antes de acceder a las claves
        if (json != null && json['main'] != null && json['weather'] != null) {
          return ClimaModelo.fromJson(json);
        } else {
          print("Estructura JSON no válida: ${respuesta.body}");
        }
      } else {
        print('Error al obtener clima: Código ${respuesta.statusCode}');
      }
    } catch (e) {
      print('Error al realizar la solicitud: $e');
    }
    return null;
  }
}
