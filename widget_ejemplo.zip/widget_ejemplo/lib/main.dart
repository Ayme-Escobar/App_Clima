import 'package:flutter/material.dart';
import 'package:widget_ejemplo/vista/clima_vista.dart';


void main() {
  runApp(WidgetApp());
}

class WidgetApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Clima',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ClimaVista(),
    );
  }
}
