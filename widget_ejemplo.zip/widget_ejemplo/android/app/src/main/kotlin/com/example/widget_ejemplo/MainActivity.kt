package com.example.widget_ejemplo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
